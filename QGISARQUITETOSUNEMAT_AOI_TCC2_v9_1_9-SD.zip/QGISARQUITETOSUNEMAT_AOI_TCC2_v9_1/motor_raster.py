"""
Silvio Cezar Dourado de Araujo
TCC II – Arquitetura e Urbanismo – UNEMAT

QGISARQUITETOSUNEMAT AOI
Plugin para geração automatizada de recortes raster (AOI)
com base em camadas XYZ e máscara vetorial.

QGIS | PyQGIS | GDAL
Versão 9.1.9-SD – 2026
"""

from qgis.core import (
    QgsMapSettings,
    QgsMapRendererCustomPainterJob,
    QgsProject,
    QgsCoordinateTransform,
    QgsRasterLayer
)
from qgis.PyQt.QtGui import QImage, QPainter
from qgis.PyQt.QtCore import QSize, Qt
import processing, os
from datetime import datetime


class RasterEngine:

    def generate_raw(self, poly, raster):

        proj = QgsProject.instance()

        base_dir = os.path.dirname(proj.fileName())
        out_dir = os.path.join(base_dir, "SDTCC2UNEMAT")
        os.makedirs(out_dir, exist_ok=True)

        # VALIDA GEOMETRIA
        geom = None
        for f in poly.getFeatures():
            g = f.geometry()
            if g and not g.isEmpty():
                geom = g
                break

        if not geom:
            # Desabilitei para teste de funcionalidade  raise Exception("Geometria inválida")
            return None

        transform = QgsCoordinateTransform(
            poly.crs(),
            raster.crs(),
            proj
        )

        bbox = transform.transformBoundingBox(geom.boundingBox())

        # CACHE INTELIGENTE
        for file in os.listdir(out_dir):
            if file.startswith("BASE_") and file.endswith(".tif"):
                path_existente = os.path.join(out_dir, file)

                layer = QgsRasterLayer(path_existente, "cache")

                if layer.isValid() and layer.extent().contains(bbox):
                    return path_existente

        # CRIA NOVO
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(out_dir, f"BASE_{stamp}.tif")

        settings = QgsMapSettings()
        settings.setLayers([raster])
        settings.setExtent(bbox)
        settings.setDestinationCrs(raster.crs())

        resolution = bbox.width() / 1200
        width = int(bbox.width() / resolution)
        height = int(bbox.height() / resolution)

        settings.setOutputSize(QSize(width, height))

        img = QImage(settings.outputSize(), QImage.Format_ARGB32)
        img.fill(Qt.transparent)

        painter = QPainter(img)

        job = QgsMapRendererCustomPainterJob(settings, painter)
        job.start()
        job.waitForFinished()

        painter.end()

        img.save(path)

        # GEOREF
        tfw = path.replace(".tif", ".tfw")

        with open(tfw, "w") as f:
            f.write(f"{bbox.width()/width}\n0\n0\n-{bbox.height()/height}\n{bbox.xMinimum()}\n{bbox.yMaximum()}")

        processing.run("gdal:assignprojection", {
            'INPUT': path,
            'CRS': raster.crs().authid()
        })

        return path


    def clip(self, raw, mask, crs, poly):

        centro = poly.extent().center()
        coord = f"{int(centro.x())}_{int(centro.y())}"

        nome = poly.name().replace(" ", "")
        stamp = datetime.now().strftime("%d%m%Y%H%M%S")

        out = raw.replace("BASE", f"SD{nome}-{coord}-{stamp}")

        processing.run("gdal:cliprasterbymasklayer", {
            'INPUT': raw,
            'MASK': mask,
            'SOURCE_SRS': crs,
            'TARGET_SRS': crs,
            'ALPHA_BAND': True,
            'CROP_TO_CUTLINE': True,
            'OUTPUT': out
        })

        return out


# PATCH AUXILIAR
def validar_geometria(poly):
    for f in poly.getFeatures():
        g = f.geometry()
        if g and not g.isEmpty():
            return g.boundingBox()
    return None