"""
Autor: Silvio Cezar Dourado de Araujo

Projeto: QGISARQUITETOSUNEMAT AOI
Tipo: Plugin QGIS para geração de recortes raster (AOI)

Instituição: Universidade do Estado de Mato Grosso (UNEMAT)
Curso: Arquitetura e Urbanismo
Trabalho: TCC II

Descrição:
Este módulo faz parte do plugin desenvolvido para automatizar
a geração de imagens raster georreferenciadas a partir de
camadas base (XYZ/Google) e polígonos (AOI), aplicando recorte
com máscara vetorial e organizando os resultados no ambiente QGIS.

Principais funcionalidades:

* Seleção de camada poligonal (AOI)
* Seleção de camada raster (XYZ ou local)
* Geração de raster base
* Sistema de cache inteligente (inventário de TIFFs)
* Recorte com máscara vetorial (GDAL)
* Criação automática de arquivos georreferenciados
* Organização em grupos no QGIS

Tecnologias:

* QGIS 3.x (PyQGIS)
* GDAL
* Python 3.12

Versão: 9.1.9-SD
Ano: 2026
"""

import os
from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QPushButton, QComboBox, QLabel, QTextEdit
from qgis.core import QgsProject, QgsVectorLayer, QgsRasterLayer, QgsWkbTypes

#  NOVO (para corrigir materialize)
from qgis.core import QgsFeatureRequest  # <-- ADICIONADO

from .servico_corte import ClipService
from .gerenciador_arquivos import listar_tifs, obter_diretorio_saida
from qgis.PyQt.QtWidgets import QListWidget

from qgis.PyQt.QtWidgets import QProgressBar
from qgis.PyQt.QtCore import QCoreApplication


class AOIDialog(QDialog):

    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface = iface
        self.service = ClipService(iface)

        self.setWindowTitle("QGISARQUITETOSUNEMAT AOI - SD - TCC2 - V9.1.9-SD")

        layout = QVBoxLayout(self)

        #  COMBOS
        self.combo_poly = QComboBox()
        self.combo_raster = QComboBox()

        layout.addWidget(QLabel("Polígono"))
        layout.addWidget(self.combo_poly)

        layout.addWidget(QLabel("Raster"))
        layout.addWidget(self.combo_raster)

        #  BOTÃO PRINCIPAL
        self.btn_run = QPushButton(" Gerar Recorte Inteligente")
        self.btn_run.setStyleSheet("""
            QPushButton {
                background:#2E7D32;
                color:white;
                font-weight:bold;
                padding:10px;
                border-radius:6px;
            }
            QPushButton:hover {background:#388E3C;}
        """)
        layout.addWidget(self.btn_run)

        #  BOTÃO SELECIONADOS
        self.btn_selected = QPushButton(" ===CONTINUACAO (OUTRA FASE)===") # <- NOVO (texto atualizado)
        self.btn_selected.setStyleSheet("""
            QPushButton {
                background:#1565C0;
                color:white;
                font-weight:bold;
                padding:10px;
                border-radius:6px;
            }
            QPushButton:hover {background:#1976D2;}
        """)
        layout.addWidget(self.btn_selected)

        #  BOTÃO ABRIR PASTA
        self.btn_open = QPushButton(" Abrir Pasta: SDTCC2UNEMAT")
        self.btn_open.clicked.connect(self.abrir_pasta)
        layout.addWidget(self.btn_open)
        
        # INVENTÁRIO
        self.lista = QListWidget()

        #  CÓDIGO ANTIGO (comentado)
        # layout.addWidget(QLabel("Inventário de TIFs"))
        # layout.addWidget(self.lista)
        #
        # self.log = QTextEdit()
        # self.log.setReadOnly(True)

        #  NOVO (corrigido - agora usa lista corretamente)
        layout.addWidget(QLabel("Inventário de TIFs"))
        layout.addWidget(self.lista)

        #  EVENTOS
        self.btn_run.clicked.connect(self.run_all)
        self.btn_selected.clicked.connect(self.run_selected)

        #  CARREGA
        self.load_layers()
        self.atualizar_inventario()

        #  ATUALIZA AUTOMÁTICO
        proj = QgsProject.instance()
        proj.layersAdded.connect(self.load_layers)
        proj.layersRemoved.connect(self.load_layers)
        proj.cleared.connect(self.load_layers)

        #  BARRA DE PROGRESSO
        self.progress = QProgressBar()
        self.progress.setValue(0)
        layout.addWidget(self.progress)
    # -----------------------------------

    def load_layers(self):

        self.combo_poly.clear()
        self.combo_raster.clear()

        for l in QgsProject.instance().mapLayers().values():

            if isinstance(l, QgsVectorLayer) and l.geometryType() == QgsWkbTypes.PolygonGeometry:
                self.combo_poly.addItem(l.name(), l)

            # elif isinstance(l, QgsRasterLayer):
            #   self.combo_raster.addItem(l.name(), l)
            elif isinstance(l, QgsRasterLayer): #  ADICIONADO (agora tenta ler o provedor do raster para evitar erros)

                provider = l.dataProvider().name() # ADICIONADO (obtém o provedor do raster)

                # >>> NOVO (estratégia robusta)
                if provider != "gdal": #  ignora rasters que não sejam gdal (ex: arquivos locais sem extensão ou formatos não suportados)
                    self.combo_raster.addItem(l.name(), l) #  ADICIONADO (agora inclui rasters não gdal, mas ignora erros de leitura)

                # >>> ignora todos os arquivos locais automaticamente

    # -----------------------------------

    def atualizar_inventario(self):

        self.lista.clear()
        
        arquivos = listar_tifs()
        ## try:
        ##    arquivos = listar_tifs()

            #  ANTIGO
            # self.log.setPlainText(...)

            #  NOVO
            ## for f in arquivos:
            ##    self.lista.addItem(f)

        ##except:
            #  ANTIGO
            # self.log.setPlainText(...)

            #  NOVO
            ## self.lista.addItem("Diretório ainda não criado.")

        if not arquivos:
            self.lista.addItem("Nenhum TIF encontrado.")
        else:
            for f in arquivos:
                self.lista.addItem(f)        

    # -----------------------------------

    def run_all(self):

        raster = self.combo_raster.currentData()

        #  NOVO (pega só o selecionado)
        poly = self.combo_poly.currentData()

        if not raster:
            #  ANTIGO
            # self.log.setPlainText(" Selecione um raster.")
            return

        if not poly:
            return

        #  CÓDIGO ANTIGO (comentado)
        # for i in range(self.combo_poly.count()):
        #     poly = self.combo_poly.itemData(i)
        #     self.service.run(poly, raster)

        #  NOVO (correto)

        # antigo sem barra de progresso feats = poly.getFeatures()
        feats = list(poly.getFeatures())  #  importante converter pra lista
        total = len(feats)

        if total == 0:
            return

        # INICIA PROGRESSO
        self.progress.setMaximum(total)
        self.progress.setValue(0)

        # # antigo for f in feats:
        for i, f in enumerate(feats):

            request = QgsFeatureRequest().setFilterFid(f.id())
            temp = poly.materialize(request)

            if temp.featureCount() == 0:
                continue

            self.service.run(temp, raster)
            #  ATUALIZA BARRA
            self.progress.setValue(i + 1)

            # NÃO TRAVA QGIS
            QCoreApplication.processEvents()
        self.atualizar_inventario()

    # -----------------------------------

    def run_selected(self):

        raster = self.combo_raster.currentData()
        poly_layer = self.combo_poly.currentData()

        if not poly_layer:
            return

        feats = poly_layer.selectedFeatures()

        if not feats:
            return
        
        # IMPORTANTE: converter pra lista para evitar problemas com materialize
        feats = list(feats)

        total = len(feats)

        #  INICIA PROGRESSO
        self.progress.setMaximum(total)
        self.progress.setValue(0)
        self.iface.mapCanvas().zoomToSelected(poly_layer)

        ##for f in feats:
        for i, f in enumerate(feats):


            #  ANTIGO (errado)
            # temp = poly_layer.materialize([f.id()])

            #  NOVO (correto QGIS 3.40)
            request = QgsFeatureRequest().setFilterFid(f.id())
            temp = poly_layer.materialize(request)

            if temp.featureCount() == 0:
                continue

            self.service.run(temp, raster)
            #  ATUALIZA
            self.progress.setValue(i + 1)

            QCoreApplication.processEvents()

        self.atualizar_inventario()

    # -----------------------------------

    def abrir_pasta(self):

        try:
            pasta = obter_diretorio_saida()

            #  NOVO (robusto)
            if not os.path.exists(pasta):
                os.makedirs(pasta, exist_ok=True)

            os.startfile(pasta)

        except Exception as e:
            self.lista.addItem(f"Erro ao abrir pasta: {e}")