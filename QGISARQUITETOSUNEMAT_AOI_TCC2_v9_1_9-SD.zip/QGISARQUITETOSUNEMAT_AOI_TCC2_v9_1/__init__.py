"""
Autor: Silvio Cezar Dourado de Araujo

Projeto: QGISARQUITETOSUNEMAT AOI
Tipo: Plugin QGIS para geração de recortes raster (AOI)

Instituição: Universidade do Estado de Mato Grosso (UNEMAT)
Curso: Arquitetura e Urbanismo
Trabalho: TCC II

Descrição:
Este módulo faz parte do plugin desenvolvido para automatizar
a geração de imagens raster georreferenciadas a partir de
camadas base (XYZ/Google) e polígonos (AOI), aplicando recorte
com máscara vetorial e organizando os resultados no ambiente QGIS.

Principais funcionalidades:

* Seleção de camada poligonal (AOI)
* Seleção de camada raster (XYZ ou local)
* Geração de raster base
* Sistema de cache inteligente (inventário de TIFFs)
* Recorte com máscara vetorial (GDAL)
* Criação automática de arquivos georreferenciados
* Organização em grupos no QGIS

Tecnologias:

* QGIS 3.x (PyQGIS)
* GDAL
* Python 3.12

Versão: 9.1.9-SD
Ano: 2026
"""
# -*- coding: utf-8 -*-

def classFactory(iface):
    from .plugin import QGISArquitetosUnematAOI
    return QGISArquitetosUnematAOI(iface)