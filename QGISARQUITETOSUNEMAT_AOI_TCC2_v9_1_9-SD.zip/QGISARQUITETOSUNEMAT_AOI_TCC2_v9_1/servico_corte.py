"""
Silvio Cezar Dourado de Araujo
TCC II – Arquitetura e Urbanismo – UNEMAT

QGISARQUITETOSUNEMAT AOI
Plugin para geração automatizada de recortes raster (AOI)
com base em camadas XYZ e máscara vetorial.

QGIS | PyQGIS | GDAL
Versão 9.1.9-SD – 2026
"""

from qgis.core import QgsProject, QgsFeatureRequest

from .motor_raster import RasterEngine
from .mascara_vetorial import VectorMask
from .gerenciador_arquivos import FileManager


class ClipService:

    def __init__(self, iface):
        self.iface = iface
        self.engine = RasterEngine()
        self.mask = VectorMask()
        self.file = FileManager()

    def run(self, poly, raster):

        proj = QgsProject.instance()
        crs = proj.crs().authid()

        nome_base = poly.name() #  nome do polígono

        for f in poly.getFeatures():

            #  CORREÇÃO 
            req = QgsFeatureRequest().setFilterFid(f.id())
            temp = poly.materialize(req)

            if temp.featureCount() == 0:
                continue

            raw = self.engine.generate_raw(temp, raster)
            mask = self.mask.create_mask(temp)
            
            if not raw:
                continue

           # NOME BASE (ANTES ESTAVA ERRADO)
            output = self.engine.clip(raw, mask, crs, temp)

            self.file.add_to_qgis(self.iface, output)