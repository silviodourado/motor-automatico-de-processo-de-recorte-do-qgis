"""
Silvio Cezar Dourado de Araujo
TCC II – Arquitetura e Urbanismo – UNEMAT

QGISARQUITETOSUNEMAT AOI
Plugin para geração automatizada de recortes raster (AOI)
com base em camadas XYZ e máscara vetorial.

QGIS | PyQGIS | GDAL
Versão 9.1.9-SD – 2026
"""

import os
from qgis.core import (
    QgsRasterLayer,
    QgsProject,
    QgsLayerTreeGroup,
    QgsMultiBandColorRenderer
)


class FileManager:

    def add_to_qgis(self, iface, path):

        project = QgsProject.instance()
        root = project.layerTreeRoot()

        grupo = root.findGroup("SDTCC2UNEMAT")

        if not grupo:
            grupo = root.addGroup("SDTCC2UNEMAT")

        nome = os.path.basename(path)

        layer = QgsRasterLayer(path, nome)

        if layer.isValid():

            project.addMapLayer(layer, False)
            grupo.addLayer(layer)

            provider = layer.dataProvider()

            renderer = QgsMultiBandColorRenderer(
                provider,
                1,
                2,
                3
            )

            layer.setRenderer(renderer)

            if layer.bandCount() >= 4:
                layer.renderer().setAlphaBand(4)

            layer.triggerRepaint()

            iface.mapCanvas().setExtent(layer.extent())
            iface.mapCanvas().refresh()


#  FORA DA CLASSE (MUITO IMPORTANTE)
def obter_diretorio_saida():

    proj = QgsProject.instance()

    caminho_projeto = proj.fileName()  #  DEFINE PRIMEIRO O CAMINHO DO PROJETO, POIS SE O PROJETO NÃO ESTIVER SALVO, O CAMINHO VAI SER VAZIO E A PASTA DE SAÍDA VAI SER O DIRETÓRIO DO USUÁRIO  

    if not caminho_projeto:
        base_dir = os.path.expanduser("~") # USUÁRIO COMO PADRÃO SE PROJETO NÃO ESTIVER SALVO
    else:
        base_dir = os.path.dirname(caminho_projeto)

    out_dir = os.path.join(base_dir, "SDTCC2UNEMAT")

    os.makedirs(out_dir, exist_ok=True)

    return out_dir

#  FORA DA CLASSE (MUITO IMPORTANTE)
def listar_tifs():
    pasta = obter_diretorio_saida()

    arquivos = []
    for f in os.listdir(pasta):
        if f.lower().endswith(".tif"):
            arquivos.append(f)

    return sorted(arquivos)