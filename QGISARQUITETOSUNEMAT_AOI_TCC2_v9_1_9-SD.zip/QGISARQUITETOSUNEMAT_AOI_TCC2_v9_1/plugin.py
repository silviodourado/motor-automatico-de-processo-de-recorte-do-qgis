"""
Autor: Silvio Cezar Dourado de Araujo

Projeto: QGISARQUITETOSUNEMAT AOI
Tipo: Plugin QGIS para geração de recortes raster (AOI)

Instituição: Universidade do Estado de Mato Grosso (UNEMAT)
Curso: Arquitetura e Urbanismo
Trabalho: TCC II

Descrição:
Este módulo faz parte do plugin desenvolvido para automatizar
a geração de imagens raster georreferenciadas a partir de
camadas base (XYZ/Google) e polígonos (AOI), aplicando recorte
com máscara vetorial e organizando os resultados no ambiente QGIS.

Principais funcionalidades:

* Seleção de camada poligonal (AOI)
* Seleção de camada raster (XYZ ou local)
* Geração de raster base
* Sistema de cache inteligente (inventário de TIFFs)
* Recorte com máscara vetorial (GDAL)
* Criação automática de arquivos georreferenciados
* Organização em grupos no QGIS

Tecnologias:

* QGIS 3.x (PyQGIS)
* GDAL
* Python 3.12

Versão: 9.1.9-SD
Ano: 2026
"""

from qgis.PyQt.QtWidgets import QAction
from .dialogo import AOIDialog

class QGISArquitetosUnematAOI:

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        self.action = QAction("QGISARQUITETOSUNEMAT AOI - SILVIO DOURADO", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("SDTCC2UNEMAT-V9x", self.action)

    def unload(self):
        self.iface.removePluginMenu("SDTCC2UNEMAT-V9x", self.action)

    def run(self):
        if not self.dialog:
            self.dialog = AOIDialog(self.iface)
        self.dialog.show()
        self.dialog.exec_()