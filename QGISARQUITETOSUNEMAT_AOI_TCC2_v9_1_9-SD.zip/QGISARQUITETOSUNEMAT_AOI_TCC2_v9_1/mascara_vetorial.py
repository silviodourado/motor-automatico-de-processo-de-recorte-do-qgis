"""
Silvio Cezar Dourado de Araujo
TCC II – Arquitetura e Urbanismo – UNEMAT

QGISARQUITETOSUNEMAT AOI
Plugin para geração automatizada de recortes raster (AOI)
com base em camadas XYZ e máscara vetorial.

QGIS | PyQGIS | GDAL
Versão 9.1.9-SD – 2026
"""

import os
from datetime import datetime
from qgis.core import QgsVectorFileWriter, QgsProject

class VectorMask:

    def create_mask(self, layer):

        proj = QgsProject.instance()

        base = os.path.dirname(proj.fileName())
        path = os.path.join(base, f"mask_{datetime.now().timestamp()}.gpkg")

        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "GPKG"

        QgsVectorFileWriter.writeAsVectorFormatV3(
            layer,
            path,
            proj.transformContext(),
            opts
        )

        return path